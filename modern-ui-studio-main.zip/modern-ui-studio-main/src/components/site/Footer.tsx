import { Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ArrowUp, MapPin, Phone, Mail, Clock } from "lucide-react";
import { company, nav, services } from "@/lib/site";
import { Logo } from "./Header";

export function Footer() {
  const [show, setShow] = useState(false);
  useEffect(() => {
    const on = () => setShow(window.scrollY > 800);
    window.addEventListener("scroll", on, { passive: true });
    return () => window.removeEventListener("scroll", on);
  }, []);
  return (
    <footer className="border-t border-border bg-secondary">
      <div className="mx-auto grid max-w-7xl gap-12 px-5 py-16 sm:grid-cols-2 lg:grid-cols-4 lg:px-8">
        <div className="space-y-5">
          <Logo />
          <p className="max-w-xs text-sm leading-relaxed text-muted-foreground">
            Maçonnerie, carrelage, aménagement extérieur et béton armé dans le Chablais et sur l'arc lémanique.
          </p>
        </div>
        <div>
          <h3 className="eyebrow mb-5">Navigation</h3>
          <ul className="space-y-3 text-sm">
            {nav.map((n) => (
              <li key={n.to}><Link to={n.to} className="text-foreground/80 hover:text-primary-glow">{n.label}</Link></li>
            ))}
            <li><Link to="/contact" className="text-foreground/80 hover:text-primary-glow">Contact</Link></li>
          </ul>
        </div>
        <div>
          <h3 className="eyebrow mb-5">Services</h3>
          <ul className="space-y-3 text-sm">
            {services.map((s) => (
              <li key={s.slug}>
                <Link to="/services/$slug" params={{ slug: s.slug }} className="text-foreground/80 hover:text-primary-glow">{s.title}</Link>
              </li>
            ))}
          </ul>
        </div>
        <div>
          <h3 className="eyebrow mb-5">Contact</h3>
          <ul className="space-y-4 text-sm text-foreground/80">
            <li className="flex gap-3"><MapPin size={16} className="mt-0.5 shrink-0 text-primary" /><span>{company.street}<br />{company.city}, {company.country}</span></li>
            <li className="flex gap-3"><Phone size={16} className="mt-0.5 shrink-0 text-primary" /><a href={company.phoneHref} className="hover:text-primary-glow">{company.phone}</a></li>
            <li className="flex gap-3"><Mail size={16} className="mt-0.5 shrink-0 text-primary" /><a href={`mailto:${company.email}`} className="hover:text-primary-glow">{company.email}</a></li>
            <li className="flex gap-3"><Clock size={16} className="mt-0.5 shrink-0 text-primary" /><span>{company.hours.map(([d, h]) => <span key={d} className="block">{d} : {h}</span>)}</span></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-border">
        <div className="mx-auto flex max-w-7xl flex-col gap-3 px-5 py-6 text-xs text-muted-foreground sm:flex-row sm:items-center sm:justify-between lg:px-8">
          <p>© {new Date().getFullYear()} {company.name}. Tous droits réservés.</p>
          <div className="flex gap-6">
            <Link to="/mentions-legales" className="hover:text-primary-glow">Mentions légales</Link>
            <Link to="/mentions-legales" hash="confidentialite" className="hover:text-primary-glow">Confidentialité</Link>
          </div>
        </div>
      </div>
      <button
        onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
        aria-label="Retour en haut"
        className={`fixed bottom-6 right-6 z-40 grid h-12 w-12 place-items-center bg-primary text-primary-foreground shadow-lg transition-all hover:bg-primary-glow ${show ? "opacity-100" : "pointer-events-none translate-y-4 opacity-0"}`}
      >
        <ArrowUp size={18} />
      </button>
    </footer>
  );
}
