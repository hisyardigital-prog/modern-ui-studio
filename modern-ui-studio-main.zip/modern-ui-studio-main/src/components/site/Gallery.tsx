import { useEffect, useState } from "react";
import { X, ChevronLeft, ChevronRight } from "lucide-react";
import { gallery, services } from "@/lib/site";
import { cn } from "@/lib/utils";

const cats = ["Tous", ...services.map((s) => s.title)];

export function Gallery() {
  const [cat, setCat] = useState("Tous");
  const [open, setOpen] = useState<number | null>(null);
  const items = cat === "Tous" ? gallery : gallery.filter((g) => g.cat === cat);

  useEffect(() => {
    if (open === null) return;
    const on = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(null);
      if (e.key === "ArrowRight") setOpen((o) => (o === null ? o : (o + 1) % items.length));
      if (e.key === "ArrowLeft") setOpen((o) => (o === null ? o : (o - 1 + items.length) % items.length));
    };
    window.addEventListener("keydown", on);
    return () => window.removeEventListener("keydown", on);
  }, [open, items.length]);

  const cur = open !== null ? items[open] : null;

  return (
    <div>
      <div className="mb-10 flex gap-2 overflow-x-auto pb-2" role="tablist" aria-label="Filtrer par catégorie">
        {cats.map((c) => (
          <button
            key={c}
            role="tab"
            aria-selected={cat === c}
            onClick={() => setCat(c)}
            className={cn(
              "shrink-0 border px-4 py-2.5 text-xs font-medium uppercase tracking-[0.12em] transition-colors",
              cat === c ? "border-primary bg-primary text-primary-foreground" : "border-border text-foreground/70 hover:border-primary hover:text-primary-glow",
            )}
          >
            {c}
          </button>
        ))}
      </div>
      <div className="columns-1 gap-5 sm:columns-2 lg:columns-3">
        {items.map((g, i) => (
          <button
            key={g.title + cat}
            onClick={() => setOpen(i)}
            className="group relative mb-5 block w-full overflow-hidden rounded-[10px] border border-border text-left animate-in fade-in zoom-in-95 duration-500"
            aria-label={`Agrandir : ${g.title}`}
          >
            <img src={g.src} alt={`${g.title} – image d'illustration`} loading="lazy" className={cn("w-full object-cover transition-transform duration-[1.2s] group-hover:scale-105", g.tall ? "aspect-[3/4]" : "aspect-[4/3]")} />
            <div className="absolute inset-0 bg-linear-to-t from-background/90 via-transparent to-transparent opacity-80 transition-opacity group-hover:opacity-100" />
            <div className="absolute inset-x-0 bottom-0 p-5">
              <span className="eyebrow text-[10px]">{g.cat}</span>
              <p className="mt-1 font-display text-lg font-semibold text-foreground">{g.title}</p>
            </div>
            <span className="absolute left-4 top-4 bg-background/70 px-2 py-1 text-[10px] uppercase tracking-[0.15em] text-foreground/80 backdrop-blur">Illustration</span>
          </button>
        ))}
      </div>
      {cur && (
        <div role="dialog" aria-modal="true" aria-label={cur.title} className="fixed inset-0 z-[60] flex items-center justify-center bg-background/95 p-4 backdrop-blur animate-in fade-in" onClick={() => setOpen(null)}>
          <button className="absolute right-5 top-5 grid h-12 w-12 place-items-center border border-border text-foreground" aria-label="Fermer" onClick={() => setOpen(null)}><X /></button>
          <button className="absolute left-3 grid h-12 w-12 place-items-center border border-border bg-background/60 text-foreground sm:left-8" aria-label="Précédente" onClick={(e) => { e.stopPropagation(); setOpen((o) => (o! - 1 + items.length) % items.length); }}><ChevronLeft /></button>
          <figure className="max-h-full max-w-5xl" onClick={(e) => e.stopPropagation()}>
            <img src={cur.src} alt={cur.title} className="max-h-[80vh] w-auto rounded-[8px] object-contain" />
            <figcaption className="mt-4 text-center text-sm text-muted-foreground">{cur.title} · {cur.cat} · Image d'illustration</figcaption>
          </figure>
          <button className="absolute right-3 grid h-12 w-12 place-items-center border border-border bg-background/60 text-foreground sm:right-8" aria-label="Suivante" onClick={(e) => { e.stopPropagation(); setOpen((o) => (o! + 1) % items.length); }}><ChevronRight /></button>
        </div>
      )}
    </div>
  );
}
