import { Link } from "@tanstack/react-router";
import { ArrowRight, ArrowUpRight, Phone } from "lucide-react";
import type { ReactNode } from "react";
import { company, type Service } from "@/lib/site";
import { Reveal } from "./Reveal";

export const btnPrimary =
  "group inline-flex items-center justify-center gap-3 bg-primary px-7 py-4 text-xs font-semibold uppercase tracking-[0.16em] text-primary-foreground transition-all hover:bg-primary-glow active:scale-[0.98]";
export const btnGhost =
  "inline-flex items-center justify-center gap-3 border border-foreground/25 px-7 py-4 text-xs font-semibold uppercase tracking-[0.16em] text-foreground transition-all hover:border-primary hover:text-primary-glow active:scale-[0.98]";

export function SectionHead({ eyebrow, title, children, center }: { eyebrow: string; title: ReactNode; children?: ReactNode; center?: boolean }) {
  return (
    <Reveal className={center ? "mx-auto max-w-2xl text-center" : "max-w-2xl"}>
      <div className={`mb-5 flex items-center gap-4 ${center ? "justify-center" : ""}`}>
        <span className="h-px w-12 bg-primary" />
        <span className="eyebrow">{eyebrow}</span>
      </div>
      <h2 className="text-balance text-3xl font-semibold leading-[1.1] text-foreground sm:text-4xl lg:text-5xl">{title}</h2>
      {children && <p className="mt-5 text-base leading-relaxed text-muted-foreground">{children}</p>}
    </Reveal>
  );
}

export function PageHero({ eyebrow, title, text, image }: { eyebrow: string; title: ReactNode; text?: string; image: string }) {
  return (
    <section className="relative flex min-h-[70vh] items-end overflow-hidden pb-16 pt-32">
      <img src={image} alt="" className="hero-zoom absolute inset-0 h-full w-full object-cover" />
      <div className="absolute inset-0 bg-linear-to-t from-background via-background/70 to-background/30" />
      <div className="relative mx-auto w-full max-w-7xl px-5 lg:px-8">
        <div className="mb-5 flex items-center gap-4"><span className="h-px w-12 bg-primary" /><span className="eyebrow">{eyebrow}</span></div>
        <h1 className="max-w-4xl text-balance text-4xl font-bold leading-[1.05] text-foreground sm:text-5xl lg:text-6xl">{title}</h1>
        {text && <p className="mt-6 max-w-2xl text-lg leading-relaxed text-foreground/80">{text}</p>}
        <p className="mt-8 text-[11px] uppercase tracking-[0.2em] text-muted-foreground">Image d'illustration</p>
      </div>
    </section>
  );
}

export function ServiceCard({ s, i = 0 }: { s: Service; i?: number }) {
  return (
    <Reveal delay={i * 80}>
      <Link to="/services/$slug" params={{ slug: s.slug }} className="group relative block overflow-hidden rounded-[10px] border border-border bg-card">
        <div className="aspect-[4/5] overflow-hidden">
          <img src={s.image} alt={`${s.title} – image d'illustration`} loading="lazy" className="h-full w-full object-cover transition-transform duration-[1.2s] ease-out group-hover:scale-110" />
        </div>
        <div className="absolute inset-0 bg-linear-to-t from-background via-background/40 to-transparent" />
        <div className="absolute inset-x-0 bottom-0 p-6">
          <span className="font-serif text-4xl italic text-primary-glow">{s.num}</span>
          <h3 className="mt-2 text-xl font-semibold text-foreground">{s.title}</h3>
          <p className="mt-2 text-sm leading-relaxed text-foreground/70">{s.short}</p>
          <span className="mt-5 inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.16em] text-primary-glow">
            Découvrir <ArrowUpRight size={14} className="transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
          </span>
        </div>
      </Link>
    </Reveal>
  );
}

export function CtaBand() {
  return (
    <section className="px-5 py-24 lg:px-8">
      <Reveal className="relative mx-auto max-w-7xl overflow-hidden rounded-[12px] border border-border bg-card px-6 py-16 text-center sm:px-16">
        <div className="pointer-events-none absolute -right-20 -top-20 h-72 w-72 rounded-full bg-primary/20 blur-3xl" />
        <span className="eyebrow">Votre projet</span>
        <h2 className="mx-auto mt-5 max-w-3xl text-balance text-3xl font-semibold text-foreground sm:text-5xl">
          Parlons de votre <span className="font-serif italic text-copper-gradient">prochain projet.</span>
        </h2>
        <p className="mx-auto mt-5 max-w-2xl text-muted-foreground">
          Vous avez un projet de maçonnerie, de carrelage ou d'aménagement extérieur ? Contactez-nous pour discuter de vos besoins.
        </p>
        <div className="mt-10 flex flex-col justify-center gap-3 sm:flex-row">
          <Link to="/contact" className={btnPrimary}>Demander un devis <ArrowRight size={16} className="transition-transform group-hover:translate-x-1" /></Link>
          <a href={company.phoneHref} className={btnGhost}><Phone size={16} /> Appeler maintenant</a>
        </div>
      </Reveal>
    </section>
  );
}
