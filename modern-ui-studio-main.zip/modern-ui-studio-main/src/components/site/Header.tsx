import { Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Menu, X, Phone } from "lucide-react";
import { nav, company } from "@/lib/site";
import { cn } from "@/lib/utils";

export function Logo() {
  return (
    <Link to="/" className="group flex items-center gap-3" aria-label="RS Maçonnerie, accueil">
      <span className="grid h-10 w-10 place-items-center border border-primary/60 font-display text-sm font-bold tracking-widest text-primary-glow transition-colors group-hover:bg-primary group-hover:text-primary-foreground">
        RS
      </span>
      <span className="leading-tight">
        <span className="block font-display text-sm font-bold tracking-[0.28em] text-foreground">MAÇONNERIE</span>
        <span className="block text-[10px] tracking-[0.3em] text-muted-foreground">SÀRL · AIGLE</span>
      </span>
    </Link>
  );
}

export function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  useEffect(() => {
    const on = () => setScrolled(window.scrollY > 24);
    on();
    window.addEventListener("scroll", on, { passive: true });
    return () => window.removeEventListener("scroll", on);
  }, []);
  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
  }, [open]);

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-all duration-500",
        scrolled || open ? "border-b border-border bg-background/85 backdrop-blur-xl" : "bg-transparent",
      )}
    >
      <div className="mx-auto flex h-20 max-w-7xl items-center justify-between px-5 lg:px-8">
        <Logo />
        <nav className="hidden items-center gap-8 lg:flex" aria-label="Navigation principale">
          {nav.map((n) => (
            <Link
              key={n.to}
              to={n.to}
              activeOptions={{ exact: n.to === "/" }}
              className="relative py-2 text-[13px] font-medium uppercase tracking-[0.14em] text-foreground/80 transition-colors hover:text-primary-glow data-[status=active]:text-primary-glow after:absolute after:inset-x-0 after:-bottom-0.5 after:h-px after:origin-left after:scale-x-0 after:bg-primary after:transition-transform data-[status=active]:after:scale-x-100 hover:after:scale-x-100"
            >
              {n.label}
            </Link>
          ))}
        </nav>
        <div className="flex items-center gap-3">
          <Link
            to="/contact"
            className="hidden border border-primary px-5 py-3 text-xs font-semibold uppercase tracking-[0.16em] text-primary-glow transition-all hover:bg-primary hover:text-primary-foreground sm:inline-flex"
          >
            Demander un devis
          </Link>
          <button
            className="grid h-11 w-11 place-items-center border border-border text-foreground lg:hidden"
            onClick={() => setOpen((o) => !o)}
            aria-expanded={open}
            aria-label={open ? "Fermer le menu" : "Ouvrir le menu"}
          >
            {open ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </div>
      <div
        className={cn(
          "fixed inset-x-0 top-20 bottom-0 bg-background transition-all duration-500 lg:hidden",
          open ? "visible opacity-100" : "invisible -translate-y-3 opacity-0",
        )}
      >
        <nav className="flex flex-col gap-1 px-5 pt-8" aria-label="Navigation mobile">
          {nav.map((n, i) => (
            <Link
              key={n.to}
              to={n.to}
              onClick={() => setOpen(false)}
              activeOptions={{ exact: n.to === "/" }}
              className="flex items-baseline gap-4 border-b border-border py-5 font-display text-2xl font-semibold text-foreground data-[status=active]:text-primary-glow"
            >
              <span className="text-xs text-primary">0{i + 1}</span>
              {n.label}
            </Link>
          ))}
          <Link to="/contact" onClick={() => setOpen(false)} className="mt-8 bg-primary py-4 text-center text-sm font-semibold uppercase tracking-[0.16em] text-primary-foreground">
            Demander un devis
          </Link>
          <a href={company.phoneHref} className="mt-3 flex items-center justify-center gap-2 border border-border py-4 text-sm text-foreground">
            <Phone size={16} /> {company.phone}
          </a>
        </nav>
      </div>
    </header>
  );
}
