import { createFileRoute } from "@tanstack/react-router";
import { MapPin } from "lucide-react";
import { images, services } from "@/lib/site";
import { PageHero, SectionHead, ServiceCard, CtaBand } from "@/components/site/Bits";
import { Reveal } from "@/components/site/Reveal";

export const Route = createFileRoute("/a-propos")({
  head: () => ({
    meta: [
      { title: "À propos – RS Maçonnerie Sàrl, Aigle" },
      { name: "description", content: "RS Maçonnerie, entreprise basée à Aigle : Rui et son équipe, plus de 25 ans d'expérience annoncés en maçonnerie et carrelage." },
      { property: "og:title", content: "À propos – RS Maçonnerie Sàrl" },
    ],
  }),
  component: About,
});

function About() {
  return (
    <>
      <PageHero eyebrow="À propos" image={images.hero} title={<>Une entreprise <span className="font-serif italic text-copper-gradient">ancrée à Aigle.</span></>} text="Maçonnerie, carrelage, aménagement extérieur et béton armé dans le Chablais et sur l'arc lémanique." />
      <section className="mx-auto grid max-w-7xl gap-14 px-5 py-24 lg:grid-cols-2 lg:px-8">
        <SectionHead eyebrow="L'entreprise" title="Rui et son équipe." />
        <Reveal delay={120} className="space-y-5 leading-relaxed text-muted-foreground">
          <p>RS Maçonnerie Sàrl est une entreprise de maçonnerie et de rénovation basée à Aigle. Rui et son équipe interviennent auprès des particuliers et des professionnels de la région.</p>
          <p>L'entreprise annonce plus de 25 ans d'expérience dans le métier : une connaissance du terrain qui se traduit par un travail soigné, de la préparation du chantier jusqu'aux finitions.</p>
          <p>Nos cinq domaines d'expertise – carrelage intérieur, carrelage extérieur, aménagement extérieur, maçonnerie et béton armé – nous permettent d'accompagner des projets variés.</p>
        </Reveal>
      </section>
      <section className="bg-secondary py-24">
        <div className="mx-auto grid max-w-7xl items-center gap-12 px-5 lg:grid-cols-2 lg:px-8">
          <Reveal><p className="font-display text-[8rem] font-extrabold leading-none text-copper-gradient sm:text-[11rem]">25+</p></Reveal>
          <SectionHead eyebrow="Expérience" title="Plus de 25 ans d'expérience annoncés.">
            Une expérience présentée par l'entreprise, au service de vos projets de construction et de rénovation.
          </SectionHead>
        </div>
      </section>
      <section className="mx-auto max-w-7xl px-5 py-24 lg:px-8">
        <SectionHead eyebrow="Expertise" title="Cinq domaines d'expertise." />
        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-5">
          {services.map((s, i) => <ServiceCard key={s.slug} s={s} i={i} />)}
        </div>
      </section>
      <section className="border-y border-border bg-secondary py-20">
        <div className="mx-auto flex max-w-7xl flex-col items-start gap-6 px-5 lg:flex-row lg:items-center lg:justify-between lg:px-8">
          <h2 className="text-2xl font-semibold text-foreground sm:text-3xl">Implantés à Aigle, actifs dans le Chablais et sur l'arc lémanique.</h2>
          <span className="inline-flex shrink-0 items-center gap-2 text-primary-glow"><MapPin size={18} /> Route d'Evian 100, 1860 Aigle</span>
        </div>
      </section>
      <CtaBand />
    </>
  );
}
