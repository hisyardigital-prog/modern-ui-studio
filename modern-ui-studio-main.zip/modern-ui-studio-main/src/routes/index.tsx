import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, MapPin } from "lucide-react";
import { company, images, services } from "@/lib/site";
import { Reveal } from "@/components/site/Reveal";
import { SectionHead, ServiceCard, CtaBand, btnPrimary, btnGhost } from "@/components/site/Bits";
import { Gallery } from "@/components/site/Gallery";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "RS Maçonnerie Sàrl – Maçonnerie, carrelage & béton armé à Aigle" },
      { name: "description", content: "Entreprise de maçonnerie à Aigle : carrelage intérieur et extérieur, aménagement extérieur, maçonnerie et béton armé dans le Chablais et sur l'arc lémanique." },
    ],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "HomeAndConstructionBusiness",
          name: company.name,
          telephone: company.phone,
          email: company.email,
          address: { "@type": "PostalAddress", streetAddress: company.street, postalCode: "1860", addressLocality: "Aigle", addressCountry: "CH" },
          openingHours: "Mo-Fr 08:00-18:00",
          areaServed: ["Chablais", "Arc lémanique"],
        }),
      },
    ],
  }),
  component: Index,
});

const pillars = [
  ["Savoir-faire", "Une expérience annoncée de plus de 25 ans"],
  ["Proximité", "Basés à Aigle, actifs dans le Chablais"],
  ["Polyvalence", "Cinq domaines d'expertise complémentaires"],
  ["Écoute", "Un interlocuteur direct pour votre projet"],
];

function Index() {
  return (
    <>
      {/* Hero */}
      <section className="relative flex min-h-[100svh] items-center overflow-hidden">
        <img src={images.hero} alt="Villa contemporaine en pierre naturelle et béton au crépuscule – image d'illustration" className="hero-zoom absolute inset-0 h-full w-full object-cover object-[70%_center]" fetchPriority="high" />
        <div className="absolute inset-0 bg-linear-to-r from-background via-background/80 to-background/10" />
        <div className="absolute inset-x-0 bottom-0 h-40 bg-linear-to-t from-background to-transparent" />
        <div className="relative mx-auto w-full max-w-7xl px-5 pt-24 lg:px-8">
          <div className="max-w-3xl">
            <div className="mb-7 flex items-center gap-4 animate-in fade-in slide-in-from-bottom-4 duration-700">
              <span className="h-px w-16 bg-primary" />
              <span className="eyebrow">Maçonnerie · Carrelage · Rénovation</span>
            </div>
            <h1 className="text-[2.6rem] font-extrabold uppercase leading-[1.02] text-foreground sm:text-6xl lg:text-7xl animate-in fade-in slide-in-from-bottom-6 duration-1000">
              <span className="text-copper-gradient">L'art de construire.</span>
              <br />
              <span className="font-serif text-[0.85em] font-semibold normal-case italic tracking-normal">Le savoir-faire de transformer.</span>
            </h1>
            <p className="mt-8 max-w-xl text-lg leading-relaxed text-foreground/80 animate-in fade-in duration-1000 [animation-delay:300ms] [animation-fill-mode:both]">
              Nous vous accompagnons dans vos projets de maçonnerie, carrelage, aménagement extérieur et béton armé dans le Chablais et sur l'arc lémanique.
            </p>
            <div className="mt-10 flex flex-col gap-3 sm:flex-row animate-in fade-in duration-1000 [animation-delay:500ms] [animation-fill-mode:both]">
              <Link to="/services" className={btnPrimary}>Découvrir nos services <ArrowRight size={16} className="transition-transform group-hover:translate-x-1" /></Link>
              <Link to="/contact" className={btnGhost}>Demander un devis</Link>
            </div>
          </div>
        </div>
        <div className="absolute bottom-8 left-1/2 hidden -translate-x-1/2 flex-col items-center gap-3 text-[10px] uppercase tracking-[0.3em] text-muted-foreground sm:flex" aria-hidden>
          <span className="flex h-10 w-6 justify-center rounded-full border border-foreground/30 pt-2"><span className="scroll-dot h-2 w-0.5 rounded bg-primary-glow" /></span>
          Défiler
        </div>
        <span className="absolute bottom-8 right-6 text-[10px] uppercase tracking-[0.2em] text-muted-foreground">Image d'illustration</span>
      </section>

      {/* Pillars strip */}
      <section className="border-y border-border bg-secondary">
        <div className="mx-auto grid max-w-7xl grid-cols-2 lg:grid-cols-4">
          {pillars.map(([t, d], i) => (
            <Reveal key={t} delay={i * 80} className="border-border p-6 sm:p-8 [&:not(:last-child)]:border-r max-lg:[&:nth-child(2)]:border-r-0 max-lg:[&:nth-child(-n+2)]:border-b">
              <span className="font-serif text-2xl italic text-primary">0{i + 1}</span>
              <h3 className="mt-2 text-sm font-semibold uppercase tracking-[0.14em] text-foreground">{t}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{d}</p>
            </Reveal>
          ))}
        </div>
      </section>

      {/* Intro */}
      <section className="mx-auto grid max-w-7xl items-center gap-14 px-5 py-24 lg:grid-cols-2 lg:px-8 lg:py-32">
        <Reveal className="relative">
          <div className="absolute -left-4 -top-4 h-32 w-32 border-l border-t border-primary" />
          <img src={images.mac} alt="Maçon posant des pierres naturelles – image d'illustration" loading="lazy" className="relative aspect-[4/5] w-full rounded-[10px] object-cover" />
          <div className="absolute -bottom-6 right-6 bg-primary px-6 py-5 text-primary-foreground">
            <p className="font-display text-4xl font-extrabold">25+</p>
            <p className="text-xs font-semibold uppercase tracking-[0.14em]">ans d'expérience annoncés</p>
          </div>
        </Reveal>
        <div>
          <SectionHead eyebrow="RS Maçonnerie" title={<>Le savoir-faire au service de <span className="font-serif italic text-copper-gradient">vos projets.</span></>} />
          <Reveal delay={150}>
            <p className="mt-6 leading-relaxed text-muted-foreground">
              Basée à Aigle, RS Maçonnerie intervient dans la région du Chablais et de l'arc lémanique. Rui et son équipe mettent à votre service une expérience annoncée de plus de 25 ans dans le métier.
            </p>
            <p className="mt-4 leading-relaxed text-muted-foreground">
              De la maçonnerie au béton armé, du carrelage à l'aménagement de vos extérieurs, nous abordons chaque chantier avec rigueur et sens du détail.
            </p>
            <Link to="/a-propos" className="group mt-8 inline-flex items-center gap-3 text-sm font-semibold uppercase tracking-[0.16em] text-primary-glow">
              En savoir plus <ArrowRight size={16} className="transition-transform group-hover:translate-x-1" />
            </Link>
          </Reveal>
        </div>
      </section>

      {/* Services */}
      <section className="bg-secondary py-24 lg:py-32">
        <div className="mx-auto max-w-7xl px-5 lg:px-8">
          <div className="flex flex-col justify-between gap-6 lg:flex-row lg:items-end">
            <SectionHead eyebrow="Services" title={<>Nos domaines <span className="font-serif italic text-copper-gradient">d'expertise.</span></>} />
            <Link to="/services" className={btnGhost}>Tous les services</Link>
          </div>
          <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {services.map((s, i) => (
              <div key={s.slug} className={i < 2 ? "lg:col-span-1" : ""}>
                <ServiceCard s={s} i={i} />
              </div>
            ))}
            <Reveal delay={400} className="flex flex-col justify-between rounded-[10px] border border-primary/40 bg-card p-8">
              <div>
                <span className="eyebrow">Un projet ?</span>
                <h3 className="mt-4 text-2xl font-semibold text-foreground">Décrivez-nous vos besoins.</h3>
                <p className="mt-3 text-sm leading-relaxed text-muted-foreground">Nous étudions votre demande et revenons vers vous pour en discuter.</p>
              </div>
              <Link to="/contact" className={`${btnPrimary} mt-8`}>Demander un devis</Link>
            </Reveal>
          </div>
        </div>
      </section>

      {/* Experience */}
      <section className="relative overflow-hidden py-24 lg:py-36">
        <div className="mx-auto grid max-w-7xl items-center gap-12 px-5 lg:grid-cols-12 lg:px-8">
          <Reveal className="lg:col-span-5">
            <p className="font-display text-[9rem] font-extrabold leading-none text-copper-gradient sm:text-[13rem]">25<span className="text-primary">+</span></p>
          </Reveal>
          <div className="lg:col-span-7">
            <SectionHead eyebrow="Expérience" title="Une expérience annoncée de plus de 25 ans.">
              Rui et son équipe mettent leur connaissance du métier au service de chaque chantier : préparation, exécution et finitions sont abordées avec la même exigence, que le projet soit petit ou grand.
            </SectionHead>
          </div>
        </div>
      </section>

      {/* Gallery */}
      <section className="bg-secondary py-24 lg:py-32">
        <div className="mx-auto max-w-7xl px-5 lg:px-8">
          <SectionHead eyebrow="Réalisations" title={<>Le savoir-faire <span className="font-serif italic text-copper-gradient">en images.</span></>}>
            Images d'illustration, en attendant les photographies des chantiers réalisés par l'entreprise.
          </SectionHead>
          <div className="mt-12"><Gallery /></div>
        </div>
      </section>

      {/* Area */}
      <section className="mx-auto grid max-w-7xl items-center gap-12 px-5 py-24 lg:grid-cols-2 lg:px-8 lg:py-32">
        <div>
          <SectionHead eyebrow="Zone d'intervention" title="Ancrés à Aigle, présents dans votre région.">
            RS Maçonnerie intervient dans la région du Chablais et de l'arc lémanique.
          </SectionHead>
          <Reveal delay={150} className="mt-8 flex flex-wrap gap-3">
            {["Aigle", "Chablais", "Arc lémanique"].map((z) => (
              <span key={z} className="inline-flex items-center gap-2 border border-border px-4 py-2.5 text-sm text-foreground"><MapPin size={14} className="text-primary" />{z}</span>
            ))}
          </Reveal>
          <Reveal delay={250}><Link to="/zone-intervention" className={`${btnGhost} mt-10`}>Voir la zone</Link></Reveal>
        </div>
        <Reveal className="overflow-hidden rounded-[10px] border border-border">
          <iframe
            title="Carte – RS Maçonnerie, Route d'Evian 100, Aigle"
            src="https://www.openstreetmap.org/export/embed.html?bbox=6.75%2C46.25%2C7.10%2C46.45&layer=mapnik&marker=46.3127%2C6.9606"
            className="h-[420px] w-full grayscale invert-[0.92] hue-rotate-180"
            loading="lazy"
          />
        </Reveal>
      </section>

      <CtaBand />
    </>
  );
}
