import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowUpRight } from "lucide-react";
import { images, services } from "@/lib/site";
import { PageHero, CtaBand } from "@/components/site/Bits";
import { Reveal } from "@/components/site/Reveal";

export const Route = createFileRoute("/services/")({
  head: () => ({
    meta: [
      { title: "Services – Maçonnerie, carrelage & béton armé | RS Maçonnerie Aigle" },
      { name: "description", content: "Carrelage intérieur et extérieur, aménagement extérieur, maçonnerie et béton armé à Aigle et dans le Chablais." },
      { property: "og:title", content: "Services – RS Maçonnerie Sàrl" },
    ],
  }),
  component: Services,
});

function Services() {
  return (
    <>
      <PageHero eyebrow="Services" image={images.mac} title={<>Nos domaines <span className="font-serif italic text-copper-gradient">d'expertise.</span></>} text="Cinq métiers complémentaires pour accompagner vos projets de construction, de rénovation et d'aménagement." />
      <section className="mx-auto max-w-7xl px-5 py-24 lg:px-8">
        <div className="space-y-6">
          {services.map((s, i) => (
            <Reveal key={s.slug}>
              <Link to="/services/$slug" params={{ slug: s.slug }} className={`group grid overflow-hidden rounded-[10px] border border-border bg-card transition-colors hover:border-primary/50 md:grid-cols-2 ${i % 2 ? "md:[&>*:first-child]:order-2" : ""}`}>
                <div className="aspect-[16/10] overflow-hidden md:aspect-auto md:h-full">
                  <img src={s.image} alt={`${s.title} – image d'illustration`} loading="lazy" className="h-full w-full object-cover transition-transform duration-[1.2s] group-hover:scale-105" />
                </div>
                <div className="flex flex-col justify-center p-8 lg:p-14">
                  <span className="font-serif text-5xl italic text-primary-glow">{s.num}</span>
                  <h2 className="mt-3 text-3xl font-semibold text-foreground">{s.title}</h2>
                  <p className="mt-4 leading-relaxed text-muted-foreground">{s.intro}</p>
                  <span className="mt-8 inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.16em] text-primary-glow">Découvrir <ArrowUpRight size={14} /></span>
                </div>
              </Link>
            </Reveal>
          ))}
        </div>
      </section>
      <CtaBand />
    </>
  );
}
