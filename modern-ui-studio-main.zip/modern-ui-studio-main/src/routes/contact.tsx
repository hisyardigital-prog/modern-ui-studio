import { createFileRoute } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { z } from "zod";
import { Phone, Mail, MapPin } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { company, images, services } from "@/lib/site";
import { PageHero, btnPrimary } from "@/components/site/Bits";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Demander un devis – RS Maçonnerie Sàrl, Aigle" },
      { name: "description", content: "Contactez RS Maçonnerie à Aigle pour votre projet de maçonnerie, carrelage, aménagement extérieur ou béton armé." },
    ],
  }),
  component: Contact,
});

const schema = z.object({
  full_name: z.string().trim().min(2, "Indiquez votre nom").max(120),
  email: z.string().trim().email("E-mail invalide").max(200),
  phone: z.string().trim().max(40).optional(),
  service: z.string().min(1, "Choisissez une prestation").max(80),
  location: z.string().trim().max(160).optional(),
  description: z.string().trim().min(10, "Décrivez votre projet (10 caractères min.)").max(4000),
  consent: z.literal(true, { message: "Votre accord est requis" }),
});

const field = "w-full border border-input bg-card px-4 py-3.5 text-foreground outline-hidden transition-colors focus:border-primary";

function Contact() {
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [state, setState] = useState<"idle" | "sending" | "ok" | "error">("idle");

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    if (fd.get("website")) return;
    const parsed = schema.safeParse({
      full_name: fd.get("full_name"), email: fd.get("email"), phone: fd.get("phone") || undefined,
      service: fd.get("service"), location: fd.get("location") || undefined,
      description: fd.get("description"), consent: fd.get("consent") === "on",
    });
    if (!parsed.success) {
      const errs: Record<string, string> = {};
      for (const i of parsed.error.issues) errs[String(i.path[0])] = i.message;
      setErrors(errs);
      return;
    }
    setErrors({});
    setState("sending");
    const { error } = await supabase.from("quote_requests").insert(parsed.data);
    setState(error ? "error" : "ok");
  }

  const err = (k: string) => errors[k] && <p role="alert" className="mt-1.5 text-sm text-destructive">{errors[k]}</p>;

  return (
    <>
      <PageHero eyebrow="Contact" image={images.ext} title="Parlons de votre prochain projet." text="Décrivez-nous votre projet, nous revenons vers vous pour en discuter." />
      <section className="mx-auto grid max-w-7xl gap-12 px-5 py-24 lg:grid-cols-3 lg:px-8">
        <aside className="space-y-4">
          <a href={company.phoneHref} className="flex gap-4 border border-border bg-card p-5 text-foreground"><Phone className="text-primary" /> {company.phone}</a>
          <a href={`mailto:${company.email}`} className="flex gap-4 border border-border bg-card p-5 text-foreground"><Mail className="text-primary" /> {company.email}</a>
          <p className="flex gap-4 border border-border bg-card p-5 text-foreground"><MapPin className="text-primary" /> {company.street}, {company.city}</p>
        </aside>
        <div className="lg:col-span-2">
          {state === "ok" ? (
            <div role="status" className="border border-primary bg-card p-10">
              <h2 className="text-2xl font-semibold text-foreground">Merci, votre demande a bien été envoyée.</h2>
              <p className="mt-3 text-muted-foreground">Nous vous recontacterons dans les meilleurs délais.</p>
            </div>
          ) : (
            <form onSubmit={onSubmit} noValidate className="grid gap-5 sm:grid-cols-2">
              <input type="text" name="website" tabIndex={-1} autoComplete="off" className="hidden" aria-hidden />
              <div><label className="eyebrow mb-2 block" htmlFor="full_name">Nom et prénom *</label><input id="full_name" name="full_name" className={field} />{err("full_name")}</div>
              <div><label className="eyebrow mb-2 block" htmlFor="email">Adresse e-mail *</label><input id="email" name="email" type="email" className={field} />{err("email")}</div>
              <div><label className="eyebrow mb-2 block" htmlFor="phone">Téléphone</label><input id="phone" name="phone" type="tel" className={field} /></div>
              <div><label className="eyebrow mb-2 block" htmlFor="service">Type de prestation *</label>
                <select id="service" name="service" className={field} defaultValue=""><option value="" disabled>Choisir…</option>{services.map((s) => <option key={s.slug}>{s.title}</option>)}<option>Autre</option></select>{err("service")}</div>
              <div className="sm:col-span-2"><label className="eyebrow mb-2 block" htmlFor="location">Localisation du projet</label><input id="location" name="location" className={field} /></div>
              <div className="sm:col-span-2"><label className="eyebrow mb-2 block" htmlFor="description">Description du projet *</label><textarea id="description" name="description" rows={6} className={field} />{err("description")}</div>
              <div className="sm:col-span-2"><label className="flex gap-3 text-sm text-muted-foreground"><input type="checkbox" name="consent" className="mt-1 accent-primary" />J'accepte que mes données soient utilisées pour traiter ma demande, conformément à la politique de confidentialité.</label>{err("consent")}</div>
              {state === "error" && <p role="alert" className="text-destructive sm:col-span-2">L'envoi a échoué. Réessayez ou appelez-nous au {company.phone}.</p>}
              <button disabled={state === "sending"} className={`${btnPrimary} sm:col-span-2 disabled:opacity-60`}>{state === "sending" ? "Envoi…" : "Envoyer ma demande"}</button>
            </form>
          )}
        </div>
      </section>
    </>
  );
}
