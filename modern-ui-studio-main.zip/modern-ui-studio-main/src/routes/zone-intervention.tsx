import { createFileRoute } from "@tanstack/react-router";
import { MapPin } from "lucide-react";
import { company, images } from "@/lib/site";
import { PageHero, SectionHead, CtaBand } from "@/components/site/Bits";
import { Reveal } from "@/components/site/Reveal";

export const Route = createFileRoute("/zone-intervention")({
  head: () => ({
    meta: [
      { title: "Zone d'intervention – Aigle, Chablais, arc lémanique | RS Maçonnerie" },
      { name: "description", content: "RS Maçonnerie, basée à Aigle, intervient dans la région du Chablais et de l'arc lémanique." },
      { property: "og:title", content: "Zone d'intervention – RS Maçonnerie Sàrl" },
    ],
  }),
  component: () => (
    <>
      <PageHero eyebrow="Zone d'intervention" image={images.amen} title="Ancrés à Aigle, présents dans votre région." text="RS Maçonnerie intervient dans la région du Chablais et de l'arc lémanique." />
      <section className="mx-auto grid max-w-7xl gap-12 px-5 py-24 lg:grid-cols-5 lg:px-8">
        <div className="lg:col-span-2">
          <SectionHead eyebrow="Notre base" title="Aigle, au cœur du Chablais." />
          <Reveal delay={120} className="mt-8 space-y-3">
            {[["Siège", `${company.street}, ${company.city}`], ["Région", "Chablais"], ["Région", "Arc lémanique"]].map(([k, v]) => (
              <div key={v} className="flex items-start gap-4 border border-border bg-card p-5">
                <MapPin size={18} className="mt-0.5 shrink-0 text-primary" />
                <div><p className="eyebrow text-[10px]">{k}</p><p className="mt-1 text-foreground">{v}</p></div>
              </div>
            ))}
            <p className="pt-3 text-sm text-muted-foreground">Votre projet se situe dans la région ? Contactez-nous pour vérifier ensemble sa faisabilité.</p>
          </Reveal>
        </div>
        <Reveal className="overflow-hidden rounded-[10px] border border-border lg:col-span-3">
          <iframe
            title="Carte – RS Maçonnerie à Aigle"
            src="https://www.openstreetmap.org/export/embed.html?bbox=6.55%2C46.20%2C7.15%2C46.55&layer=mapnik&marker=46.3127%2C6.9606"
            className="h-[520px] w-full grayscale invert-[0.92] hue-rotate-180"
            loading="lazy"
          />
        </Reveal>
      </section>
      <CtaBand />
    </>
  ),
});
