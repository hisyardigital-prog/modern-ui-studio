import { createFileRoute } from "@tanstack/react-router";
import { company } from "@/lib/site";

export const Route = createFileRoute("/mentions-legales")({
  head: () => ({
    meta: [
      { title: "Mentions légales & confidentialité – RS Maçonnerie Sàrl" },
      { name: "description", content: "Mentions légales et politique de confidentialité de RS Maçonnerie Sàrl, Aigle." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: () => (
    <div className="mx-auto max-w-3xl px-5 pb-24 pt-40">
      <span className="eyebrow">Informations légales</span>
      <h1 className="mt-4 text-4xl font-bold text-foreground">Mentions légales</h1>
      <div className="mt-10 space-y-4 leading-relaxed text-muted-foreground">
        <p><strong className="text-foreground">{company.name}</strong><br />{company.street}<br />{company.city}, {company.country}</p>
        <p>Téléphone : {company.phone}<br />E-mail : {company.email}</p>
        <p>Les photographies présentées sur ce site sont des images d'illustration et ne représentent pas des chantiers réalisés par l'entreprise.</p>
      </div>
      <h2 id="confidentialite" className="mt-16 scroll-mt-28 text-3xl font-bold text-foreground">Protection des données</h2>
      <div className="mt-6 space-y-4 leading-relaxed text-muted-foreground">
        <p>Les données transmises via le formulaire de demande de devis (nom, e-mail, téléphone, localisation et description du projet) sont utilisées uniquement pour traiter votre demande et vous recontacter.</p>
        <p>Elles ne sont ni vendues ni transmises à des tiers. Vous pouvez demander l'accès, la rectification ou la suppression de vos données en écrivant à {company.email}.</p>
      </div>
    </div>
  ),
});
