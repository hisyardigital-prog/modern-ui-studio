import { createFileRoute } from "@tanstack/react-router";
import { images } from "@/lib/site";
import { PageHero, CtaBand } from "@/components/site/Bits";
import { Gallery } from "@/components/site/Gallery";

export const Route = createFileRoute("/realisations")({
  head: () => ({
    meta: [
      { title: "Réalisations – RS Maçonnerie Sàrl, Aigle" },
      { name: "description", content: "Galerie de maçonnerie, carrelage, aménagement extérieur et béton armé. Images d'illustration en attendant les photos de chantiers." },
      { property: "og:title", content: "Réalisations – RS Maçonnerie Sàrl" },
    ],
  }),
  component: () => (
    <>
      <PageHero eyebrow="Réalisations" image={images.ext} title={<>Le savoir-faire <span className="font-serif italic text-copper-gradient">en images.</span></>} text="Les images présentées sont des illustrations. Elles seront remplacées par les photographies des chantiers réalisés par RS Maçonnerie." />
      <section className="mx-auto max-w-7xl px-5 py-24 lg:px-8"><Gallery /></section>
      <CtaBand />
    </>
  ),
});
