import { createFileRoute, notFound, Link } from "@tanstack/react-router";
import { Check } from "lucide-react";
import { getService, services } from "@/lib/site";
import { PageHero, SectionHead, ServiceCard, CtaBand } from "@/components/site/Bits";
import { Reveal } from "@/components/site/Reveal";

export const Route = createFileRoute("/services/$slug")({
  loader: ({ params }) => {
    const s = getService(params.slug);
    if (!s) throw notFound();
    return { slug: s.slug };
  },
  head: ({ loaderData }) => {
    const s = loaderData ? getService(loaderData.slug) : undefined;
    if (!s) return { meta: [{ title: "Service – RS Maçonnerie" }, { name: "robots", content: "noindex" }] };
    return {
      meta: [
        { title: `${s.title} à Aigle – RS Maçonnerie Sàrl` },
        { name: "description", content: `${s.title} dans le Chablais et sur l'arc lémanique. ${s.short}` },
        { property: "og:title", content: `${s.title} – RS Maçonnerie Sàrl` },
        { property: "og:description", content: s.short },
      ],
    };
  },
  notFoundComponent: () => (
    <div className="mx-auto max-w-xl px-5 py-48 text-center">
      <h1 className="text-3xl font-semibold text-foreground">Service introuvable</h1>
      <Link to="/services" className="mt-6 inline-block text-primary-glow">Voir tous les services</Link>
    </div>
  ),
  errorComponent: () => <div className="px-5 py-48 text-center text-foreground">Cette page n'a pas pu être chargée.</div>,
  component: ServicePage,
});

function ServicePage() {
  const { slug } = Route.useLoaderData();
  const s = getService(slug)!;
  const related = services.filter((x) => x.slug !== s.slug).slice(0, 3);
  return (
    <>
      <PageHero eyebrow={`${s.num} · ${s.title}`} image={s.image} title={s.headline} />
      <section className="mx-auto grid max-w-7xl gap-14 px-5 py-24 lg:grid-cols-2 lg:px-8">
        <div>
          <SectionHead eyebrow="Présentation" title={s.title} />
          <Reveal delay={120}><p className="mt-6 text-lg leading-relaxed text-muted-foreground">{s.intro}</p></Reveal>
          <Reveal delay={200}>
            <h3 className="mt-12 eyebrow">Nos interventions</h3>
            <ul className="mt-5 grid gap-3 sm:grid-cols-2">
              {s.points.map((p) => (
                <li key={p} className="flex items-start gap-3 border border-border bg-card p-4 text-sm text-foreground"><Check size={16} className="mt-0.5 shrink-0 text-primary" />{p}</li>
              ))}
            </ul>
          </Reveal>
        </div>
        <Reveal className="relative">
          <img src={s.image} alt={`${s.title} – image d'illustration`} loading="lazy" className="aspect-[4/5] w-full rounded-[10px] object-cover" />
          <span className="absolute left-4 top-4 bg-background/70 px-2 py-1 text-[10px] uppercase tracking-[0.15em] text-foreground/80 backdrop-blur">Image d'illustration</span>
        </Reveal>
      </section>
      <section className="bg-secondary py-24">
        <div className="mx-auto max-w-7xl px-5 lg:px-8">
          <SectionHead eyebrow="Avant de commencer" title="Points à considérer pour votre projet." />
          <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {s.considerations.map((c, i) => (
              <Reveal key={c} delay={i * 80} className="border-t border-primary pt-6">
                <span className="font-serif text-3xl italic text-primary-glow">0{i + 1}</span>
                <p className="mt-3 font-medium text-foreground">{c}</p>
              </Reveal>
            ))}
          </div>
        </div>
      </section>
      <section className="mx-auto max-w-7xl px-5 py-24 lg:px-8">
        <SectionHead eyebrow="Voir aussi" title="Services associés." />
        <div className="mt-12 grid gap-5 sm:grid-cols-3">
          {related.map((r, i) => <ServiceCard key={r.slug} s={r} i={i} />)}
        </div>
      </section>
      <CtaBand />
    </>
  );
}
