import hero from "@/assets/hero.jpg.asset.json";
import int from "@/assets/int.jpg.asset.json";
import ext from "@/assets/ext.jpg.asset.json";
import amen from "@/assets/amen.jpg.asset.json";
import mac from "@/assets/mac.jpg.asset.json";
import beton from "@/assets/beton.jpg.asset.json";

export const company = {
  name: "RS Maçonnerie Sàrl",
  street: "Route d'Evian 100",
  city: "1860 Aigle",
  country: "Suisse",
  phone: "+41 78 915 67 00",
  phoneHref: "tel:+41789156700",
  email: "info@ruisequeira.ch",
  hours: [
    ["Lundi – Vendredi", "08:00 – 18:00"],
    ["Samedi – Dimanche", "Fermé"],
  ] as const,
};

export const images = { hero: hero.url, int: int.url, ext: ext.url, amen: amen.url, mac: mac.url, beton: beton.url };

export type Service = {
  slug: string;
  num: string;
  title: string;
  short: string;
  headline: string;
  intro: string;
  image: string;
  points: string[];
  considerations: string[];
};

export const services: Service[] = [
  {
    slug: "carrelage-interieur",
    num: "01",
    title: "Carrelage intérieur",
    short: "Sols et murs de salles de bains, cuisines et pièces de vie, posés avec précision.",
    headline: "Des surfaces intérieures nettes, durables et soignées.",
    intro:
      "Salle de bains, cuisine, séjour ou entrée : nous posons vos revêtements de sol et de mur en carrelage, en accordant une attention particulière à la préparation du support, aux alignements et aux finitions.",
    image: int.url,
    points: ["Pose de sols et de murs", "Salles de bains et douches à l'italienne", "Cuisines et pièces de vie", "Finitions et joints soignés"],
    considerations: ["Choix du format et du matériau", "État et planéité du support", "Étanchéité des zones humides", "Calepinage et alignements"],
  },
  {
    slug: "carrelage-exterieur",
    num: "02",
    title: "Carrelage extérieur",
    short: "Terrasses, plages de piscine et accès pensés pour durer face aux saisons.",
    headline: "Des extérieurs prolongés avec élégance.",
    intro:
      "Terrasses, balcons, abords de piscine ou cheminements : le carrelage extérieur demande une mise en œuvre adaptée au climat, au gel et à l'écoulement de l'eau. Nous vous accompagnons de la préparation à la pose.",
    image: ext.url,
    points: ["Terrasses et balcons", "Abords de piscine", "Escaliers et accès", "Revêtements adaptés à l'extérieur"],
    considerations: ["Résistance au gel et antidérapant", "Pentes et évacuation de l'eau", "Préparation du support", "Joints de dilatation"],
  },
  {
    slug: "amenagement-exterieur",
    num: "03",
    title: "Aménagement extérieur",
    short: "Murs, escaliers, dallages et cheminements qui structurent votre jardin.",
    headline: "Structurer et valoriser vos espaces extérieurs.",
    intro:
      "Murets, escaliers, dallages, bordures ou cheminements : nous réalisons les ouvrages qui donnent forme à vos extérieurs, en harmonie avec votre maison et votre terrain.",
    image: amen.url,
    points: ["Murets et murs de soutènement", "Escaliers extérieurs", "Dallages et cheminements", "Bordures et finitions"],
    considerations: ["Nature et pente du terrain", "Gestion des eaux de surface", "Choix des matériaux", "Intégration au paysage"],
  },
  {
    slug: "maconnerie",
    num: "04",
    title: "Maçonnerie",
    short: "Construction, transformation et rénovation : le cœur de notre métier.",
    headline: "La maçonnerie, cœur de notre métier.",
    intro:
      "Construction, transformation ou rénovation : la maçonnerie est au centre de nos interventions. Nous travaillons avec rigueur pour des ouvrages solides et bien exécutés.",
    image: mac.url,
    points: ["Murs et cloisons", "Transformations et ouvertures", "Rénovation", "Travaux en pierre et en brique"],
    considerations: ["Contraintes structurelles", "Autorisations éventuelles", "Matériaux existants", "Coordination avec les autres corps de métier"],
  },
  {
    slug: "beton-arme",
    num: "05",
    title: "Béton armé",
    short: "Dalles, fondations et murs en béton armé pour des structures pérennes.",
    headline: "Des structures solides, de la fondation à la dalle.",
    intro:
      "Fondations, dalles, murs ou éléments porteurs : le béton armé exige préparation, coffrage et ferraillage maîtrisés. Nous réalisons ces ouvrages avec soin.",
    image: beton.url,
    points: ["Fondations", "Dalles", "Murs en béton armé", "Coffrage et ferraillage"],
    considerations: ["Plans et calculs de l'ingénieur", "Accès au chantier", "Conditions météorologiques", "Temps de séchage"],
  },
];

export const getService = (slug: string) => services.find((s) => s.slug === slug);

export const gallery = [
  { src: int.url, cat: "Carrelage intérieur", title: "Salle de bains minérale", tall: true },
  { src: ext.url, cat: "Carrelage extérieur", title: "Terrasse et plage de piscine" },
  { src: mac.url, cat: "Maçonnerie", title: "Mur en pierre naturelle" },
  { src: beton.url, cat: "Béton armé", title: "Voile en béton armé", tall: true },
  { src: amen.url, cat: "Aménagement extérieur", title: "Escalier et murets en pierre", tall: true },
  { src: hero.url, cat: "Maçonnerie", title: "Façade pierre et béton" },
];

export const nav = [
  { to: "/", label: "Accueil" },
  { to: "/a-propos", label: "À propos" },
  { to: "/services", label: "Services" },
  { to: "/realisations", label: "Réalisations" },
  { to: "/zone-intervention", label: "Zone d'intervention" },
] as const;
